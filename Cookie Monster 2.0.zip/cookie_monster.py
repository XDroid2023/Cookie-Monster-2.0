import tkinter as tk
from tkinter import ttk, scrolledtext
import random
from PIL import Image, ImageTk
import os
import subprocess
from ttkthemes import ThemedTk

class CookieMonster:
    def __init__(self, root):
        self.root = root
        self.root.title("Cookie Monster Chat")
        self.root.geometry("600x800")  # Slightly wider window
        
        # Set theme
        self.style = ttk.Style()
        self.style.configure("Custom.TFrame", background="#1E1E2E")  # Darker, richer background
        self.style.configure("Cookie.TLabel", 
                           background="#1E1E2E", 
                           foreground="#89B4FA",  # Soft blue text
                           font=("Arial", 12))
        self.style.configure("Counter.TLabel", 
                           background="#1E1E2E", 
                           foreground="#FAB387",  # Soft orange
                           font=("Arial", 16, "bold"))  # Larger counter
        
        # Main background
        self.root.configure(bg="#1E1E2E")  # Darker, richer background

        # Cookie Monster ASCII art
        self.monster_art = """
         .---. _  .---. 
        /     \\ `/     \\
       |  .-.  |  .-.  |
       |  | |  |  | |  |
       |  `-'  |  `-'  |
        \\     /  \\     /
         `---'    `---'
          .-^-._   _.-^-.
        .'\\  {|} {|} /`.
       /   \\  {|} {|}  /   \\
      /     \\    /\\   /     \\
     /       \\  /  \\ /       \\
    /         \\/    \\/         \\
   """

        # Cookie counter
        self.cookies = 0
        
        # Responses for different situations
        self.hungry_responses = [
            "ME WANT COOKIE!",
            "COOKIE! GIVE ME COOKIE!",
            "ME HUNGRY! NEED COOKIES!",
            "OM NOM NOM... NO MORE COOKIES? ME SAD.",
        ]
        
        self.happy_responses = [
            "OM NOM NOM NOM! DELICIOUS!",
            "COOKIE! ME LOVE YOU!",
            "THANK YOU FOR COOKIE!",
            "COOOOOKIE! YUM YUM YUM!",
        ]

        self.chat_responses = {
            "hello": ["HI FRIEND! YOU HAVE COOKIE?", "HELLO! ME LOVE MEETING NEW FRIENDS!", "OH BOY, NEW FRIEND! GOT ANY COOKIES?"],
            "how are you": ["ME HUNGRY... NEED COOKIES!", "ME GOOD IF ME GET COOKIE!", "ME ALWAYS HAPPY WHEN EATING COOKIES!"],
            "bye": ["NO GO! STAY AND GIVE COOKIE!", "BYE BYE! BRING COOKIES NEXT TIME!", "ME SAD TO SEE YOU GO... LIKE ME SAD WITH NO COOKIES!"],
            "cookie": ["DID SOMEONE SAY COOKIE?!", "COOKIE! WHERE? WHERE?!", "ME LOVE COOKIES! GIMME!"],
            "what": ["ME SIMPLE MONSTER. ME LIKE COOKIES!", "COOKIE IS ALL ME NEED TO KNOW!", "ME JUST WANT COOKIES!"],
            "no": ["WHY NO COOKIE? ME SAD...", "NO COOKIE MAKE MONSTER SAD!", "PLEASE GIVE COOKIE!"],
            "yes": ["YAY! COOKIE TIME?", "ME EXCITED! COOKIE COMING?", "YES YES YES! COOKIE?"]
        }

        # Cookie jokes list
        self.cookie_jokes = [
            "WHY COOKIE DOUGH GO TO DOCTOR? IT NOT FEELING BAKED! NOM NOM NOM!",
            "WHAT COOKIE MONSTER FAVORITE KIND OF MUSIC? FRESH BAKED JAZZ! NOM NOM!",
            "WHY COOKIE CRY? BECAUSE IT FEELING CRUMBLY! ME MAKE IT FEEL BETTER BY EATING IT!",
            "WHAT COOKIE SAY WHEN IT WIN RACE? THAT HOW COOKIE CRUMBLES! ME EAT WINNER!",
            "WHY CHOCOLATE CHIP COOKIE BEST DETECTIVE? IT ALWAYS FOLLOW CRUMBS! NOM NOM!",
            "WHAT COOKIE SAY TO OTHER COOKIE IN GYM? YOU LOOKING PRETTY TOUGH COOKIE! ME EAT BOTH!",
            "WHY COOKIE BAD AT SOCCER? IT ALWAYS CRUMBLE UNDER PRESSURE! ME STILL EAT IT!",
            "HOW COOKIE ANSWER PHONE? CRUMBLE? WHO DIS? NOM NOM NOM!",
            "WHAT COOKIE FAVORITE TV SHOW? BAKING BAD! ME WATCH WHILE EATING COOKIES!",
            "WHY COOKIE GO TO SCHOOL? TO BECOME ONE SMART COOKIE! ME EAT AFTER GRADUATION!",
            "WHAT GINGERBREAD MAN PUT ON BED? COOKIE SHEETS! BUT ME EAT BEFORE BEDTIME!",
            "WHY COOKIE GOOD AT MATH? IT ALWAYS ADD MORE CHOCOLATE CHIPS! NOM NOM!"
        ]
        
        # Start with age verification
        self.show_age_verification()
        self.floating_cookies = []  # Store floating cookies
    
    def show_age_verification(self):
        # Create age verification frame
        self.age_frame = ttk.Frame(self.root, style="Custom.TFrame")
        self.age_frame.pack(expand=True, fill="both")
        
        # Welcome message
        welcome_label = ttk.Label(self.age_frame, 
                                text="COOKIE MONSTER WANTS TO KNOW YOUR AGE!", 
                                style="Cookie.TLabel",
                                font=("Arial", 16, "bold"))
        welcome_label.pack(pady=20)
        
        # Age input
        self.age_var = tk.StringVar()
        age_entry = ttk.Entry(self.age_frame, 
                            textvariable=self.age_var,
                            font=("Arial", 14),
                            width=10)
        age_entry.pack(pady=10)
        
        # Verify button
        verify_button = ttk.Button(self.age_frame,
                                 text="VERIFY AGE",
                                 style="Custom.TButton",
                                 command=self.verify_age)
        verify_button.pack(pady=10)
        
        # Error message label
        self.error_label = ttk.Label(self.age_frame,
                                   text="",
                                   style="Cookie.TLabel",
                                   foreground="#E74C3C")
        self.error_label.pack(pady=10)
        
        # Cookie Monster ASCII art
        art_label = ttk.Label(self.age_frame,
                            text=self.monster_art,
                            style="Cookie.TLabel",
                            font=("Courier", 12))
        art_label.pack(pady=20)
    
    def verify_age(self):
        try:
            age = int(self.age_var.get())
            if age >= 7:
                self.age_frame.destroy()
                self.setup_gui()
            else:
                self.error_label.config(
                    text="SORRY! ME ONLY CHAT WITH FRIENDS 7 OR OLDER!\nCOME BACK WHEN YOU'RE OLDER!")
        except ValueError:
            self.error_label.config(
                text="PLEASE ENTER A VALID NUMBER!")
    
    def speak(self, message):
        # Use macOS 'say' command with a deeper voice
        subprocess.Popen(['say', '-v', 'Fred', '-r', '200', message])

    def display_message(self, message, from_user=False):
        sender = "You" if from_user else "Cookie Monster"
        timestamp = ""  # You could add time.strftime("%H:%M") here if you want timestamps
        self.chat_display.insert(tk.END, f"{timestamp}{sender}: {message}\n")
        self.chat_display.see(tk.END)
        if not from_user:
            self.speak(message)

    def get_response(self, message):
        message = message.lower().strip()
        
        # Handle joke requests
        if "joke" in message:
            return random.choice(self.cookie_jokes)
        
        # Handle greetings
        if any(word in message for word in ["hello", "hi", "hey", "howdy"]):
            return "HI FRIEND! ME LOVE MEETING NEW FRIENDS! GOT ANY COOKIES?"
        
        # Handle goodbyes
        if any(word in message for word in ["bye", "goodbye", "later"]):
            return "BYE BYE! BRING COOKIES NEXT TIME!"
        
        # Handle thank you
        if any(word in message for word in ["thank", "thanks", "thx"]):
            return "YOU WELCOME! NOW... GOT ANY COOKIES?"
        
        # Handle questions about wellbeing
        if any(phrase in message for phrase in ["how are you", "what's up", "sup"]):
            return "ME GOOD! WOULD BE BETTER WITH COOKIE!"
        
        # Handle cookie-related messages
        if "cookie" in message:
            return "DID SOMEONE SAY COOKIE?! ME LOVE COOKIES! GIMME!"
        
        # Default responses
        default_responses = [
            "ME NOT UNDERSTAND... MAYBE COOKIE WOULD HELP ME THINK BETTER!",
            "HMM... COOKIE WOULD HELP ME UNDERSTAND!",
            "ME CONFUSED! COOKIE MIGHT HELP!",
            "ME ONLY EXPERT IN COOKIES!"
        ]
        return random.choice(default_responses)

    def send_message(self):
        message = self.chat_input.get().strip()
        if message:
            self.display_message(message, from_user=True)
            self.chat_input.delete(0, tk.END)
            
            # Get and display Cookie Monster's response
            response = self.get_response(message)
            self.root.after(1000, lambda: self.display_message(response))

    def create_floating_cookie(self):
        cookie = tk.Label(
            self.main_container,
            text="🍪",
            font=("Arial", 24),
            bg="#1E1E2E"
        )
        # Start near the feed button
        x = random.randint(100, 500)
        y = 600  # Start near bottom
        cookie.place(x=x, y=y)
        return {'label': cookie, 'x': x, 'y': y}

    def float_cookie(self, cookie, steps=0):
        if steps < 30:  # Float up for 30 steps
            cookie['y'] -= 10  # Move up
            cookie['label'].place(x=cookie['x'], y=cookie['y'])
            self.root.after(50, lambda: self.float_cookie(cookie, steps + 1))
        else:
            cookie['label'].destroy()
            if cookie in self.floating_cookies:
                self.floating_cookies.remove(cookie)

    def feed_cookie(self):
        self.cookies += 1
        self.cookie_count.config(text=f"Cookies Eaten: {self.cookies}")
        
        # Create and animate floating cookies
        for _ in range(3):  # Create 3 cookies
            cookie = self.create_floating_cookie()
            self.floating_cookies.append(cookie)
            self.float_cookie(cookie)
        
        response = random.choice(self.happy_responses)
        self.display_message(response)

    def setup_gui(self):
        # Main container with padding
        self.main_container = ttk.Frame(self.root, style="Custom.TFrame")
        self.main_container.pack(fill=tk.BOTH, expand=True, padx=30, pady=25)  # More padding

        # Title frame
        self.title_frame = ttk.Frame(self.main_container, style="Custom.TFrame")
        self.title_frame.pack(fill=tk.X, pady=(0, 15))

        # Cookie Monster ASCII art with custom font and color
        self.monster_label = tk.Label(
            self.title_frame,
            text=self.monster_art,
            font=("Courier", 12, "bold"),
            fg="#89B4FA",  # Soft blue
            bg="#1E1E2E",
            justify=tk.LEFT
        )
        self.monster_label.pack(pady=(0, 15))

        # Cookie Monster title with emoji and custom font
        self.title_label = ttk.Label(
            self.title_frame,
            text="🍪 COOKIE MONSTER CHAT 🍪",
            font=("Arial", 28, "bold"),  # Larger title
            foreground="#CBA6F7",  # Soft purple
            background="#1E1E2E"
        )
        self.title_label.pack(pady=(0, 15))

        # Cookie counter with custom styling
        self.cookie_frame = ttk.Frame(self.main_container, style="Custom.TFrame")
        self.cookie_frame.pack(fill=tk.X, pady=(0, 15))

        self.cookie_count = ttk.Label(
            self.cookie_frame,
            text=f"Cookies Eaten: {self.cookies}",
            style="Counter.TLabel"
        )
        self.cookie_count.pack()

        # Chat display with custom colors
        self.chat_frame = ttk.Frame(self.main_container, style="Custom.TFrame")
        self.chat_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))

        self.chat_display = scrolledtext.ScrolledText(
            self.chat_frame,
            height=15,
            width=40,
            font=("Arial", 13),  # Slightly larger font
            wrap=tk.WORD,
            bg="#313244",  # Slightly lighter than background
            fg="#CDD6F4",  # Soft white
            insertbackground="#CDD6F4"  # Cursor color
        )
        self.chat_display.pack(fill=tk.BOTH, expand=True)
        self.display_message("ME WANT COOKIE! FEED ME!")

        # Input area with modern styling
        self.input_frame = ttk.Frame(self.main_container, style="Custom.TFrame")
        self.input_frame.pack(fill=tk.X, pady=(0, 15))

        # Chat input with custom colors
        self.chat_input = tk.Entry(
            self.input_frame,
            font=("Arial", 13),
            bg="#313244",
            fg="#CDD6F4",
            insertbackground="#CDD6F4",
            relief=tk.FLAT,
            bd=12  # Larger padding
        )
        self.chat_input.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 15))
        self.chat_input.bind('<Return>', lambda e: self.send_message())

        # Buttons frame
        self.buttons_frame = ttk.Frame(self.main_container, style="Custom.TFrame")
        self.buttons_frame.pack(fill=tk.X, pady=(0, 15))

        # Send button with custom styling
        self.send_button = tk.Button(
            self.buttons_frame,
            text="SEND MESSAGE",
            command=self.send_message,
            font=("Arial", 13, "bold"),  # Larger font
            bg="#313244",
            fg="#CDD6F4",
            activebackground="#45475A",  # Lighter on hover
            activeforeground="#CDD6F4",
            relief="flat",
            bd=0,
            padx=25,
            pady=12,  # Taller buttons
            cursor="hand2"
        )
        self.send_button.pack(side=tk.LEFT, padx=5, expand=True)

        # Feed cookie button with custom styling
        self.feed_button = tk.Button(
            self.buttons_frame,
            text="FEED COOKIE 🍪",
            command=self.feed_cookie,
            font=("Arial", 13, "bold"),  # Larger font
            bg="#313244",
            fg="#CDD6F4",
            activebackground="#45475A",  # Lighter on hover
            activeforeground="#CDD6F4",
            relief="flat",
            bd=0,
            padx=25,
            pady=12,  # Taller buttons
            cursor="hand2"
        )
        self.feed_button.pack(side=tk.LEFT, padx=5, expand=True)

if __name__ == "__main__":
    root = ThemedTk(theme="arc")  # Using a modern theme
    app = CookieMonster(root)
    root.mainloop()
